package imli.me.mycoupon.data;

import java.io.Serializable;

public class Coupon implements Serializable {

    public int image;

    public String name;

    public String remark;

}
