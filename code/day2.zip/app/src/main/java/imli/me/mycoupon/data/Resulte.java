package imli.me.mycoupon.data;

import java.util.List;

public class Resulte {

    public class CouponResult {
        public List<Coupon> data;
    }

}
