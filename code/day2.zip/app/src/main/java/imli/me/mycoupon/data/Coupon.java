package imli.me.mycoupon.data;

import java.io.Serializable;

public class Coupon implements Serializable {

    public String cover;

    public String name;

    public String description;

}
